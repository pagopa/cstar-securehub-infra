import { FooterLegal, FooterPreLogin, type PreLoginFooterLinksType } from '@pagopa/mui-italia';
import { BonusPariInfo } from '../BonusPARIInfo/BonusPARIInfo';
import { IOBanner } from '../IOBanner/IOBanner';
import { IOFeaturesBanner } from '../IOFeaturesBanner/IOFeaturesBanner';

const FOOTER_LINKS = {
    CHI_SIAMO: 'https://www.pagopa.it/it/societa/chi-siamo/',
    PNRR: 'https://www.pagopa.it/it/opportunita/pnrr/progetti/',
    MEDIA: 'https://www.pagopa.it/media/',
    LAVORA_CON_NOI: 'https://www.pagopa.it/it/lavora-con-noi/',
    INFORMATIVA_PRIVACY: '#informativa-privacy', //TODO
    CERTIFICAZIONI: 'https://www.pagopa.it/it/certificazioni/',
    SICUREZZA_DELLE_INFORMAZIONI: 'https://www.pagopa.it/it/politiche-sulla-sicurezza-delle-informazioni-e-sulla-qualita/',
    PERSONAL_DATA: 'https://privacyportal-de.onetrust.com/webform/77f17844-04c3-4969-a11d-462ee77acbe1/9ab6533d-be4a-482e-929a-0d8d2ab29df8',
    COOKIE: '#preferenze-cookie', //TODO
    TERMS_AND_CONDITIONS: 'https://www.pagopa.it/it/termini-e-condizioni-di-utilizzo-del-sito/',
    SOCIETA_TRASPARENTE: 'https://pagopa.portaleamministrazionetrasparente.it/',
    POLICY: 'https://www.pagopa.it/it/responsible-disclosure-policy/',
    MOD_231: 'https://pagopa.portaleamministrazionetrasparente.it/pagina746_altri-contenuti.html',
    A11Y: 'https://form.agid.gov.it/view/5de36b80-97b7-11f0-b1d3-cb68959f3505',
    COMPANY: 'https://www.pagopa.it/it/'
} as const;

const openExternalLink = (url: string) => window.open(url, '_blank')?.focus();

export const Footer = () => {

    const preLoginLinks: PreLoginFooterLinksType = {
        aboutUs: {
            title: undefined,
            links: [
                {
                    label: 'Chi siamo',
                    ariaLabel: 'Vai al link: Chi siamo',
                    linkType: 'external',
                    href: FOOTER_LINKS.CHI_SIAMO,
                    onClick: () => window.open(FOOTER_LINKS.CHI_SIAMO, '_blank'),
                },
                {
                    label: 'PNRR',
                    ariaLabel: 'Vai al link: PNRR',
                    linkType: 'external',
                    href: FOOTER_LINKS.PNRR,
                    onClick: () =>
                        window.open(FOOTER_LINKS.PNRR, '_blank'),
                },
                {
                    label: 'Media',
                    ariaLabel: 'Vai al link: Media',
                    linkType: 'external',
                    href: FOOTER_LINKS.MEDIA,
                    onClick: () => window.open(FOOTER_LINKS.MEDIA, '_blank'),
                },
                {
                    label: 'Lavora con noi',
                    ariaLabel: 'Vai al link: Lavora con noi',
                    linkType: 'external',
                    href: FOOTER_LINKS.LAVORA_CON_NOI,
                    onClick: () => window.open(FOOTER_LINKS.LAVORA_CON_NOI, '_blank'),
                },
            ],
        },
        resources: {
            title: 'Risorse',
            links: [
                {
                    label: 'Informativa Privacy',
                    ariaLabel: 'Vai al link: Informativa Privacy',
                    linkType: 'external',
                    href: FOOTER_LINKS.INFORMATIVA_PRIVACY,
                    // onClick: () => window.open(FOOTER_LINKS.INFORMATIVA_PRIVACY, '_blank'),
                },
                {
                    label: 'Certificazioni',
                    ariaLabel: 'Vai al link: Certificazioni',
                    linkType: 'external',
                    href: FOOTER_LINKS.CERTIFICAZIONI,
                    onClick: () => window.open(FOOTER_LINKS.CERTIFICAZIONI, '_blank'),
                },
                {
                    label: 'Sicurezza delle informazioni',
                    ariaLabel: 'Vai al link: Sicurezza delle informazioni',
                    linkType: 'external',
                    href: FOOTER_LINKS.SICUREZZA_DELLE_INFORMAZIONI,
                    onClick: () => window.open(FOOTER_LINKS.SICUREZZA_DELLE_INFORMAZIONI, '_blank'),
                },
                {
                    label: 'Diritto alla protezione dei dati personali',
                    ariaLabel: 'Vai al link: Diritto alla protezione dei dati personali',
                    linkType: 'external',
                    href: FOOTER_LINKS.PERSONAL_DATA,
                    onClick: () => window.open(FOOTER_LINKS.PERSONAL_DATA, '_blank')
                },
                {
                    label: 'Preferenze Cookie',
                    ariaLabel: 'Vai al link: Preferenze Cookie',
                    linkType: 'external',
                    href: FOOTER_LINKS.COOKIE,
                    // onClick: () => { window.open(FOOTER_LINKS.COOKIE, '_blank') },
                },
                {
                    label: 'Termini e Condizioni',
                    ariaLabel: 'Vai al link: Termini e Condizioni',
                    linkType: 'external',
                    href: FOOTER_LINKS.TERMS_AND_CONDITIONS,
                    onClick: () => window.open(FOOTER_LINKS.TERMS_AND_CONDITIONS, '_blank')
                },
                {
                    label: 'Società trasparente',
                    ariaLabel: 'Vai al link: Società trasparente',
                    linkType: 'external',
                    href: FOOTER_LINKS.SOCIETA_TRASPARENTE,
                    onClick: () => window.open(FOOTER_LINKS.SOCIETA_TRASPARENTE, '_blank')
                },
                {
                    label: 'Responsible Disclosure Policy',
                    ariaLabel: 'Vai al link: Responsible Disclosure Policy',
                    linkType: 'external',
                    href: FOOTER_LINKS.POLICY,
                    onClick: () => window.open(FOOTER_LINKS.POLICY, '_blank')
                },
                {
                    label: 'Modello 231',
                    ariaLabel: 'Vai al link: Modello 231',
                    linkType: 'external',
                    href: FOOTER_LINKS.MOD_231,
                    onClick: () => window.open(FOOTER_LINKS.MOD_231, '_blank')
                },
            ],
        },
        followUs: {
            title: 'Seguici su',
            socialLinks: [
                {
                    icon: 'linkedin',
                    title: 'LinkedIn',
                    href: 'https://www.linkedin.com/company/pagopa/',
                    ariaLabel: 'Link: vai al sito LinkedIn di PagoPA S.p.A.',
                },
                {
                    icon: 'instagram',
                    title: 'Instagram',
                    href: 'https://www.instagram.com/pagopaspa/',
                    ariaLabel: 'Link: vai al sito Instagram di PagoPA S.p.A.',
                },
                {
                    icon: 'threads',
                    title: 'Threads',
                    href: 'https://www.threads.net/@pagopaspa',
                    ariaLabel: 'Link: vai al sito Threads di PagoPA S.p.A.',
                },
                {
                    icon: 'youtube',
                    title: 'Youtube',
                    href: 'https://www.youtube.com/channel/UCFBGOEJUPQ6t3xtZFc_UIEQ',
                    ariaLabel: 'Link: vai al sito Youtube di PagoPA S.p.A.',
                },
            ],
            links: [
                {
                    label: 'Accessibilità',
                    ariaLabel: 'Accessibilità',
                    linkType: 'external',
                    href: FOOTER_LINKS.A11Y,
                    onClick: () => window.open(FOOTER_LINKS.A11Y, '_blank')
                },
            ],
        },
    };

    return (
        <>
            <IOFeaturesBanner />
            <BonusPariInfo />
            <IOBanner />
            <FooterPreLogin
                companyLink={{
                    ariaLabel: 'PagoPA SPA',
                    href: FOOTER_LINKS.COMPANY,
                    onClick: () => openExternalLink(FOOTER_LINKS.COMPANY)
                }}
                links={preLoginLinks}
                currentLangCode={'it'}
                languages={{
                    it: {
                        it: 'Italiano'
                    }
                }}
                onLanguageChanged={() => { }}
            />
            <FooterLegal
                content={
                    <span style={{ whiteSpace: 'pre-line' }}>
                        <b>PagoPA S.p.A</b> - Società per azioni con socio unico - capitale sociale di euro 1.000.000 interamente versato - sede legale in Roma, Piazza Colonna 370,
                        {'\n'}
                        CAP 00187 - N. di iscrizione a Registro Imprese di Roma, CF e P.IVA 15376371009
                    </span>
                }
            />
        </>
    );
};

export default Footer;