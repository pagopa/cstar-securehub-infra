import React from 'react';
import { Box, TablePagination, IconButton } from '@mui/material';
import { ChevronLeft, ChevronRight } from '@mui/icons-material';

interface CustomPaginationActionsProps {
  count: number;
  page: number;
  rowsPerPage: number;
  onPageChange: (event: React.MouseEvent<HTMLButtonElement> | null, newPage: number) => void;
}

function CustomPaginationActions({
  count,
  page,
  rowsPerPage,
  onPageChange,
}: CustomPaginationActionsProps) {
  const handleBack = (event: React.MouseEvent<HTMLButtonElement>) => {
    onPageChange(event, page - 1);
  };

  const handleNext = (event: React.MouseEvent<HTMLButtonElement>) => {
    onPageChange(event, page + 1);
  };

  const lastPage = Math.ceil(count / rowsPerPage) - 1;

  return (
    <Box sx={{ display: 'flex', alignItems: 'center' }}>
      <IconButton
        disableRipple
        disableFocusRipple
        onClick={handleBack}
        disabled={page === 0}
        sx={{
          borderRadius: 0,
          width: 32,
          height: 32,
          color: page === 0 ? '#d1d5db' : '#6b7280',
          backgroundColor: 'transparent',
          '&:hover': { backgroundColor: 'transparent' },
          '&:focus': { backgroundColor: 'transparent' },
          '&:active': { backgroundColor: 'transparent' },
          '&:disabled': { color: '#d1d5db', backgroundColor: 'transparent' },
        }}
      >
        <ChevronLeft sx={{ fontSize: 22 }} />
      </IconButton>

      <IconButton
        disableRipple
        disableFocusRipple
        onClick={handleNext}
        disabled={page >= lastPage}
        sx={{
          borderRadius: 0,
          width: 32,
          height: 32,
          color: page >= lastPage ? '#d1d5db' : '#6b7280',
          backgroundColor: 'transparent',
          '&:hover': { backgroundColor: 'transparent' },
          '&:focus': { backgroundColor: 'transparent' },
          '&:active': { backgroundColor: 'transparent' },
          '&:disabled': { color: '#d1d5db', backgroundColor: 'transparent' },
        }}
      >
        <ChevronRight sx={{ fontSize: 22 }} />
      </IconButton>
    </Box>
  );
}

interface CustomPaginatorProps {
  sortedData: any[];
  page: number;
  setPage: (page: number) => void;
  ROWS_PER_PAGE: number;
}

export default function CustomPaginator({
  sortedData,
  page,
  setPage,
  ROWS_PER_PAGE,
}: CustomPaginatorProps) {
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'center',
        px: 3,
      }}
    >
      <TablePagination
        component="div"
        count={sortedData.length}
        page={page - 1}
        onPageChange={(_, newPage) => setPage(newPage + 1)}
        rowsPerPage={ROWS_PER_PAGE}
        rowsPerPageOptions={[]}
        labelDisplayedRows={({ from, to, count }) => `${from} - ${to} di ${count}`}
        ActionsComponent={CustomPaginationActions}
        sx={{
          '& .MuiTablePagination-toolbar': {
            minHeight: '40px',
            padding: 0,
          },
          '& .MuiTablePagination-displayedRows': {
            fontSize: 14,
            color: '#6b7280',
            marginRight: 1,
                      backgroundColor: 'transparent',

          },
        }}
      />
    </Box>
  );
}